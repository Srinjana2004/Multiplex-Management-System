-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 07, 2026 at 12:34 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `multiplex_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `booking_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `show_id` bigint(20) NOT NULL,
  `movie_id` bigint(20) NOT NULL,
  `booking_time` datetime DEFAULT current_timestamp(),
  `booking_status` varchar(20) DEFAULT 'CONFIRMED',
  `total_amount` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`booking_id`, `user_id`, `show_id`, `movie_id`, `booking_time`, `booking_status`, `total_amount`) VALUES
(1, 1, 1, 1, '2026-08-05 11:33:51', 'CONFIRMED', 100),
(2, 1, 1, 1, '2026-08-05 11:41:59', 'CONFIRMED', 100),
(3, 1, 1, 1, '2026-08-05 11:42:19', 'CONFIRMED', 100),
(4, 2, 1, 1, '2026-08-05 11:42:55', 'CONFIRMED', 100),
(5, 2, 2, 2, '2026-08-05 11:44:41', 'CONFIRMED', 35),
(6, 2, 2, 2, '2026-08-05 13:00:47', 'CONFIRMED', 35),
(7, 2, 3, 3, '2026-08-05 14:37:44', 'CONFIRMED', 100),
(8, 2, 2, 2, '2026-08-05 14:44:52', 'CONFIRMED', 35),
(9, 2, 1, 1, '2026-08-05 14:47:17', 'CONFIRMED', 100),
(10, 2, 2, 2, '2026-08-05 14:48:00', 'CONFIRMED', 35),
(11, 2, 2, 2, '2026-08-05 14:48:25', 'CONFIRMED', 35),
(12, 2, 3, 3, '2026-08-05 14:57:00', 'CONFIRMED', 100),
(13, 2, 2, 2, '2026-08-05 15:09:07', 'CONFIRMED', 35),
(14, 2, 2, 2, '2026-08-06 16:20:31', 'CONFIRMED', 35);

-- --------------------------------------------------------

--
-- Table structure for table `booking_seats`
--

CREATE TABLE `booking_seats` (
  `booking_id` bigint(20) NOT NULL,
  `seat_id` bigint(20) NOT NULL,
  `seat_status` varchar(20) DEFAULT 'RESERVED'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `booking_seats`
--

INSERT INTO `booking_seats` (`booking_id`, `seat_id`, `seat_status`) VALUES
(2, 1, 'RESERVED'),
(3, 2, 'RESERVED'),
(4, 3, 'RESERVED'),
(5, 33, 'RESERVED'),
(6, 34, 'RESERVED'),
(7, 41, 'RESERVED'),
(8, 36, 'RESERVED'),
(9, 6, 'RESERVED'),
(10, 39, 'RESERVED'),
(11, 40, 'RESERVED'),
(12, 75, 'RESERVED'),
(13, 32, 'RESERVED'),
(14, 37, 'RESERVED');

-- --------------------------------------------------------

--
-- Table structure for table `movies`
--

CREATE TABLE `movies` (
  `movie_id` bigint(20) NOT NULL,
  `title` varchar(150) NOT NULL,
  `language` varchar(50) DEFAULT NULL,
  `certificate` varchar(20) DEFAULT NULL,
  `poster_url` varchar(255) DEFAULT NULL,
  `duration` int(11) NOT NULL,
  `genre` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `movies`
--

INSERT INTO `movies` (`movie_id`, `title`, `language`, `certificate`, `poster_url`, `duration`, `genre`) VALUES
(1, '123', '123', '123', NULL, 123, '123'),
(2, 'TestMovie', 'Hindi', 'U/A', NULL, 20, 'TestGenre'),
(3, 'Movie1', 'Hindi', 'U/A', NULL, 20, 'Horror');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `payment_id` bigint(20) NOT NULL,
  `booking_id` bigint(20) NOT NULL,
  `payment_method` varchar(50) NOT NULL,
  `payment_time` datetime DEFAULT current_timestamp(),
  `payment_status` varchar(20) DEFAULT 'SUCCESS'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`payment_id`, `booking_id`, `payment_method`, `payment_time`, `payment_status`) VALUES
(1, 1, 'Credit Card', '2026-08-05 11:33:51', 'SUCCESS'),
(2, 2, 'UPI', '2026-08-05 11:41:59', 'SUCCESS'),
(3, 3, 'Net Banking', '2026-08-05 11:42:19', 'SUCCESS'),
(4, 4, 'UPI', '2026-08-05 11:42:55', 'SUCCESS'),
(5, 5, 'UPI', '2026-08-05 11:44:41', 'SUCCESS'),
(6, 6, 'Net Banking', '2026-08-05 13:00:47', 'SUCCESS'),
(7, 7, 'Credit Card', '2026-08-05 14:37:44', 'SUCCESS'),
(8, 8, 'Net Banking', '2026-08-05 14:44:52', 'SUCCESS'),
(9, 9, 'Net Banking', '2026-08-05 14:47:17', 'SUCCESS'),
(10, 10, 'Net Banking', '2026-08-05 14:48:00', 'SUCCESS'),
(11, 11, 'Debit Card', '2026-08-05 14:48:25', 'SUCCESS'),
(12, 12, 'Credit Card', '2026-08-05 14:57:00', 'SUCCESS'),
(13, 13, 'Credit Card', '2026-08-05 15:09:07', 'SUCCESS'),
(14, 14, 'Debit Card', '2026-08-06 16:20:31', 'SUCCESS');

-- --------------------------------------------------------

--
-- Table structure for table `screens`
--

CREATE TABLE `screens` (
  `screen_id` bigint(20) NOT NULL,
  `screen_name` varchar(50) NOT NULL,
  `capacity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `screens`
--

INSERT INTO `screens` (`screen_id`, `screen_name`, `capacity`) VALUES
(1, 'Screen 1', 30),
(2, 'Screen 2', 10),
(3, 'Screen 4', 35),
(4, 'ScreenTest', 60);

-- --------------------------------------------------------

--
-- Table structure for table `seats`
--

CREATE TABLE `seats` (
  `seat_id` bigint(20) NOT NULL,
  `screen_id` bigint(20) NOT NULL,
  `seat_number` varchar(10) NOT NULL,
  `seat_type` varchar(20) DEFAULT NULL,
  `column` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `seats`
--

INSERT INTO `seats` (`seat_id`, `screen_id`, `seat_number`, `seat_type`, `column`) VALUES
(1, 1, 'S1', 'REGULAR', NULL),
(2, 1, 'S2', 'REGULAR', NULL),
(3, 1, 'S3', 'REGULAR', NULL),
(4, 1, 'S4', 'REGULAR', NULL),
(5, 1, 'S5', 'REGULAR', NULL),
(6, 1, 'S6', 'REGULAR', NULL),
(7, 1, 'S7', 'REGULAR', NULL),
(8, 1, 'S8', 'REGULAR', NULL),
(9, 1, 'S9', 'REGULAR', NULL),
(10, 1, 'S10', 'REGULAR', NULL),
(11, 1, 'S11', 'REGULAR', NULL),
(12, 1, 'S12', 'REGULAR', NULL),
(13, 1, 'S13', 'REGULAR', NULL),
(14, 1, 'S14', 'REGULAR', NULL),
(15, 1, 'S15', 'REGULAR', NULL),
(16, 1, 'S16', 'REGULAR', NULL),
(17, 1, 'S17', 'REGULAR', NULL),
(18, 1, 'S18', 'REGULAR', NULL),
(19, 1, 'S19', 'REGULAR', NULL),
(20, 1, 'S20', 'REGULAR', NULL),
(21, 1, 'S21', 'REGULAR', NULL),
(22, 1, 'S22', 'REGULAR', NULL),
(23, 1, 'S23', 'REGULAR', NULL),
(24, 1, 'S24', 'REGULAR', NULL),
(25, 1, 'S25', 'REGULAR', NULL),
(26, 1, 'S26', 'REGULAR', NULL),
(27, 1, 'S27', 'REGULAR', NULL),
(28, 1, 'S28', 'REGULAR', NULL),
(29, 1, 'S29', 'REGULAR', NULL),
(30, 1, 'S30', 'REGULAR', NULL),
(31, 2, 'S1', 'REGULAR', NULL),
(32, 2, 'S2', 'REGULAR', NULL),
(33, 2, 'S3', 'REGULAR', NULL),
(34, 2, 'S4', 'REGULAR', NULL),
(35, 2, 'S5', 'REGULAR', NULL),
(36, 2, 'S6', 'REGULAR', NULL),
(37, 2, 'S7', 'REGULAR', NULL),
(38, 2, 'S8', 'REGULAR', NULL),
(39, 2, 'S9', 'REGULAR', NULL),
(40, 2, 'S10', 'REGULAR', NULL),
(41, 3, 'S1', 'REGULAR', NULL),
(42, 3, 'S2', 'REGULAR', NULL),
(43, 3, 'S3', 'REGULAR', NULL),
(44, 3, 'S4', 'REGULAR', NULL),
(45, 3, 'S5', 'REGULAR', NULL),
(46, 3, 'S6', 'REGULAR', NULL),
(47, 3, 'S7', 'REGULAR', NULL),
(48, 3, 'S8', 'REGULAR', NULL),
(49, 3, 'S9', 'REGULAR', NULL),
(50, 3, 'S10', 'REGULAR', NULL),
(51, 3, 'S11', 'REGULAR', NULL),
(52, 3, 'S12', 'REGULAR', NULL),
(53, 3, 'S13', 'REGULAR', NULL),
(54, 3, 'S14', 'REGULAR', NULL),
(55, 3, 'S15', 'REGULAR', NULL),
(56, 3, 'S16', 'REGULAR', NULL),
(57, 3, 'S17', 'REGULAR', NULL),
(58, 3, 'S18', 'REGULAR', NULL),
(59, 3, 'S19', 'REGULAR', NULL),
(60, 3, 'S20', 'REGULAR', NULL),
(61, 3, 'S21', 'REGULAR', NULL),
(62, 3, 'S22', 'REGULAR', NULL),
(63, 3, 'S23', 'REGULAR', NULL),
(64, 3, 'S24', 'REGULAR', NULL),
(65, 3, 'S25', 'REGULAR', NULL),
(66, 3, 'S26', 'REGULAR', NULL),
(67, 3, 'S27', 'REGULAR', NULL),
(68, 3, 'S28', 'REGULAR', NULL),
(69, 3, 'S29', 'REGULAR', NULL),
(70, 3, 'S30', 'REGULAR', NULL),
(71, 3, 'S31', 'REGULAR', NULL),
(72, 3, 'S32', 'REGULAR', NULL),
(73, 3, 'S33', 'REGULAR', NULL),
(74, 3, 'S34', 'REGULAR', NULL),
(75, 3, 'S35', 'REGULAR', NULL),
(76, 4, 'S1', 'REGULAR', NULL),
(77, 4, 'S2', 'REGULAR', NULL),
(78, 4, 'S3', 'REGULAR', NULL),
(79, 4, 'S4', 'REGULAR', NULL),
(80, 4, 'S5', 'REGULAR', NULL),
(81, 4, 'S6', 'REGULAR', NULL),
(82, 4, 'S7', 'REGULAR', NULL),
(83, 4, 'S8', 'REGULAR', NULL),
(84, 4, 'S9', 'REGULAR', NULL),
(85, 4, 'S10', 'REGULAR', NULL),
(86, 4, 'S11', 'REGULAR', NULL),
(87, 4, 'S12', 'REGULAR', NULL),
(88, 4, 'S13', 'REGULAR', NULL),
(89, 4, 'S14', 'REGULAR', NULL),
(90, 4, 'S15', 'REGULAR', NULL),
(91, 4, 'S16', 'REGULAR', NULL),
(92, 4, 'S17', 'REGULAR', NULL),
(93, 4, 'S18', 'REGULAR', NULL),
(94, 4, 'S19', 'REGULAR', NULL),
(95, 4, 'S20', 'REGULAR', NULL),
(96, 4, 'S21', 'REGULAR', NULL),
(97, 4, 'S22', 'REGULAR', NULL),
(98, 4, 'S23', 'REGULAR', NULL),
(99, 4, 'S24', 'REGULAR', NULL),
(100, 4, 'S25', 'REGULAR', NULL),
(101, 4, 'S26', 'REGULAR', NULL),
(102, 4, 'S27', 'REGULAR', NULL),
(103, 4, 'S28', 'REGULAR', NULL),
(104, 4, 'S29', 'REGULAR', NULL),
(105, 4, 'S30', 'REGULAR', NULL),
(106, 4, 'S31', 'REGULAR', NULL),
(107, 4, 'S32', 'REGULAR', NULL),
(108, 4, 'S33', 'REGULAR', NULL),
(109, 4, 'S34', 'REGULAR', NULL),
(110, 4, 'S35', 'REGULAR', NULL),
(111, 4, 'S36', 'REGULAR', NULL),
(112, 4, 'S37', 'REGULAR', NULL),
(113, 4, 'S38', 'REGULAR', NULL),
(114, 4, 'S39', 'REGULAR', NULL),
(115, 4, 'S40', 'REGULAR', NULL),
(116, 4, 'S41', 'REGULAR', NULL),
(117, 4, 'S42', 'REGULAR', NULL),
(118, 4, 'S43', 'REGULAR', NULL),
(119, 4, 'S44', 'REGULAR', NULL),
(120, 4, 'S45', 'REGULAR', NULL),
(121, 4, 'S46', 'REGULAR', NULL),
(122, 4, 'S47', 'REGULAR', NULL),
(123, 4, 'S48', 'REGULAR', NULL),
(124, 4, 'S49', 'REGULAR', NULL),
(125, 4, 'S50', 'REGULAR', NULL),
(126, 4, 'S51', 'REGULAR', NULL),
(127, 4, 'S52', 'REGULAR', NULL),
(128, 4, 'S53', 'REGULAR', NULL),
(129, 4, 'S54', 'REGULAR', NULL),
(130, 4, 'S55', 'REGULAR', NULL),
(131, 4, 'S56', 'REGULAR', NULL),
(132, 4, 'S57', 'REGULAR', NULL),
(133, 4, 'S58', 'REGULAR', NULL),
(134, 4, 'S59', 'REGULAR', NULL),
(135, 4, 'S60', 'REGULAR', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `shows`
--

CREATE TABLE `shows` (
  `show_id` bigint(20) NOT NULL,
  `movie_id` bigint(20) NOT NULL,
  `screen_id` bigint(20) NOT NULL,
  `show_date` date NOT NULL,
  `show_time` time NOT NULL,
  `ticket_price` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `shows`
--

INSERT INTO `shows` (`show_id`, `movie_id`, `screen_id`, `show_date`, `show_time`, `ticket_price`) VALUES
(1, 1, 1, '2026-08-05', '20:05:00', 100),
(2, 2, 2, '2026-08-05', '21:14:00', 35),
(3, 3, 3, '2026-08-05', '23:06:00', 100);

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE `tickets` (
  `ticket_id` bigint(20) NOT NULL,
  `payment_id` bigint(20) NOT NULL,
  `ticket_no` varchar(50) NOT NULL,
  `qr_code` varchar(255) DEFAULT NULL,
  `generate_time` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` bigint(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(20) NOT NULL DEFAULT 'CUSTOMER'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `name`, `email`, `password`, `role`) VALUES
(1, 'RahulAdmin', 'rahuladmin@gmail.com', '123', 'ADMIN'),
(2, 'RahulUser', 'rahuluser@gmail.com', '123', 'CUSTOMER'),
(3, 'TestAdmin', 'testadmin@gmail.com', '123', 'ADMIN'),
(4, 'TestUser', 'testuser@gmail.com', '1234', 'CUSTOMER'),
(5, 'TAdm', 'tadm@gmail.com', '1234', 'ADMIN');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`booking_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `show_id` (`show_id`),
  ADD KEY `movie_id` (`movie_id`);

--
-- Indexes for table `booking_seats`
--
ALTER TABLE `booking_seats`
  ADD PRIMARY KEY (`booking_id`,`seat_id`),
  ADD KEY `seat_id` (`seat_id`);

--
-- Indexes for table `movies`
--
ALTER TABLE `movies`
  ADD PRIMARY KEY (`movie_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`payment_id`),
  ADD UNIQUE KEY `booking_id` (`booking_id`);

--
-- Indexes for table `screens`
--
ALTER TABLE `screens`
  ADD PRIMARY KEY (`screen_id`);

--
-- Indexes for table `seats`
--
ALTER TABLE `seats`
  ADD PRIMARY KEY (`seat_id`),
  ADD KEY `screen_id` (`screen_id`);

--
-- Indexes for table `shows`
--
ALTER TABLE `shows`
  ADD PRIMARY KEY (`show_id`),
  ADD KEY `movie_id` (`movie_id`),
  ADD KEY `screen_id` (`screen_id`);

--
-- Indexes for table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`ticket_id`),
  ADD UNIQUE KEY `payment_id` (`payment_id`),
  ADD UNIQUE KEY `ticket_no` (`ticket_no`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `booking_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `movies`
--
ALTER TABLE `movies`
  MODIFY `movie_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `payment_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `screens`
--
ALTER TABLE `screens`
  MODIFY `screen_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `seats`
--
ALTER TABLE `seats`
  MODIFY `seat_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=136;

--
-- AUTO_INCREMENT for table `shows`
--
ALTER TABLE `shows`
  MODIFY `show_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tickets`
--
ALTER TABLE `tickets`
  MODIFY `ticket_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `bookings_ibfk_2` FOREIGN KEY (`show_id`) REFERENCES `shows` (`show_id`),
  ADD CONSTRAINT `bookings_ibfk_3` FOREIGN KEY (`movie_id`) REFERENCES `movies` (`movie_id`);

--
-- Constraints for table `booking_seats`
--
ALTER TABLE `booking_seats`
  ADD CONSTRAINT `booking_seats_ibfk_1` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`booking_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `booking_seats_ibfk_2` FOREIGN KEY (`seat_id`) REFERENCES `seats` (`seat_id`);

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`booking_id`) ON DELETE CASCADE;

--
-- Constraints for table `seats`
--
ALTER TABLE `seats`
  ADD CONSTRAINT `seats_ibfk_1` FOREIGN KEY (`screen_id`) REFERENCES `screens` (`screen_id`) ON DELETE CASCADE;

--
-- Constraints for table `shows`
--
ALTER TABLE `shows`
  ADD CONSTRAINT `shows_ibfk_1` FOREIGN KEY (`movie_id`) REFERENCES `movies` (`movie_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `shows_ibfk_2` FOREIGN KEY (`screen_id`) REFERENCES `screens` (`screen_id`) ON DELETE CASCADE;

--
-- Constraints for table `tickets`
--
ALTER TABLE `tickets`
  ADD CONSTRAINT `tickets_ibfk_1` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`payment_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
