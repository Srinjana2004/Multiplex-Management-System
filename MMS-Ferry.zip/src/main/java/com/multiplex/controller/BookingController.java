package com.multiplex.controller;

import com.multiplex.model.*;
import com.multiplex.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/bookings")
@CrossOrigin(origins = "*")
public class BookingController {

    @Autowired private BookingRepository bookingRepository;
    @Autowired private PaymentRepository paymentRepository;
    @Autowired private BookingSeatRepository bookingSeatRepository;
    @Autowired private SeatRepository seatRepository;

    // Endpoint to fetch all reserved seat IDs for a specific show
    @GetMapping("/reserved-seats/{showId}")
    public List<Long> getReservedSeats(@PathVariable Long showId) {
        return bookingSeatRepository.findReservedSeatIdsByShowId(showId);
    }

    // Process booking with reservation check
    @PostMapping
    public ResponseEntity<?> createBooking(@RequestBody Map<String, Object> payload) {
        Long userId = Long.valueOf(payload.get("userId").toString());
        Long showId = Long.valueOf(payload.get("showId").toString());
        Long movieId = Long.valueOf(payload.get("movieId").toString());
        Long seatId = Long.valueOf(payload.get("seatId").toString());
        Double amount = Double.valueOf(payload.get("amount").toString());
        String method = payload.get("paymentMethod").toString();

        // 1. Check if seat is already reserved for this show
        List<Long> reservedSeatIds = bookingSeatRepository.findReservedSeatIdsByShowId(showId);
        if (reservedSeatIds.contains(seatId)) {
            return ResponseEntity.badRequest().body(Map.of("error", "Seat already reserved! Please select a different seat."));
        }

        // 2. Create Booking
        User user = new User(); user.setUserId(userId);
        Show show = new Show(); show.setShowId(showId);
        Movie movie = new Movie(); movie.setMovieId(movieId);

        Booking booking = new Booking();
        booking.setUser(user);
        booking.setShow(show);
        booking.setMovie(movie);
        booking.setTotalAmount(amount);
        Booking savedBooking = bookingRepository.save(booking);

        // 3. Mark Seat as Reserved in booking_seats table
        Seat seat = seatRepository.findById(seatId).orElseThrow();
        BookingSeat bookingSeat = new BookingSeat();
        bookingSeat.setId(new BookingSeatId(savedBooking.getBookingId(), seat.getSeatId()));
        bookingSeat.setBooking(savedBooking);
        bookingSeat.setSeat(seat);
        bookingSeat.setSeatStatus("RESERVED");
        bookingSeatRepository.save(bookingSeat);

        // 4. Create Payment
        Payment payment = new Payment();
        payment.setBooking(savedBooking);
        payment.setPaymentMethod(method);
        paymentRepository.save(payment);

        return ResponseEntity.ok(Map.of(
                "status", "SUCCESS",
                "bookingId", savedBooking.getBookingId(),
                "seatNumber", seat.getSeatNumber(),
                "amountPaid", amount,
                "paymentMethod", method
        ));
    }

    // Fetch all bookings made by a specific user (for User Profile page)
    @GetMapping("/user/{userId}")
    public List<Map<String, Object>> getUserBookings(@PathVariable Long userId) {
        List<Booking> bookings = bookingRepository.findAll().stream()
                .filter(b -> b.getUser() != null && b.getUser().getUserId().equals(userId))
                .toList();

        return bookings.stream().map(b -> {
            List<Long> seatIds = bookingSeatRepository.findAll().stream()
                    .filter(bs -> bs.getBooking().getBookingId().equals(b.getBookingId()))
                    .map(bs -> bs.getSeat().getSeatId())
                    .toList();

            List<String> seatNumbers = seatRepository.findAllById(seatIds).stream()
                    .map(Seat::getSeatNumber)
                    .toList();

            Payment payment = paymentRepository.findAll().stream()
                    .filter(p -> p.getBooking().getBookingId().equals(b.getBookingId()))
                    .findFirst().orElse(null);

            return Map.<String, Object>of(
                    "bookingId", b.getBookingId(),
                    "movieTitle", b.getMovie() != null ? b.getMovie().getTitle() : "N/A",
                    "showDate", b.getShow() != null ? b.getShow().getShowDate() : "N/A",
                    "showTime", b.getShow() != null ? b.getShow().getShowTime() : "N/A",
                    "seats", String.join(", ", seatNumbers),
                    "totalAmount", b.getTotalAmount() != null ? b.getTotalAmount() : 0.0,
                    "status", b.getBookingStatus() != null ? b.getBookingStatus() : "CONFIRMED",
                    "paymentMethod", payment != null ? payment.getPaymentMethod() : "N/A",
                    "bookingTime", b.getBookingTime() != null ? b.getBookingTime().toString() : "N/A"
            );
        }).toList();
    }
}