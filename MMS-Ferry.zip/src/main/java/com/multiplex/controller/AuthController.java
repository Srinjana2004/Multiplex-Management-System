package com.multiplex.controller;

import com.multiplex.model.User;
import com.multiplex.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    @Autowired
    private UserRepository userRepository;

    // R.1.1: Register User
    @PostMapping("/register")
    public String registerUser(@RequestBody User user) {
        if (userRepository.findByEmail(user.getEmail()).isPresent()) {
            return "Email already registered!";
        }
        if (user.getRole() == null || user.getRole().isEmpty()) {
            user.setRole("CUSTOMER");
        }
        userRepository.save(user);
        return "Registration successful!";
    }

    // R.1.2 & R.2.1: Login User / Admin
    @PostMapping("/login")
    public User loginUser(@RequestBody User loginData) {
        Optional<User> userOpt = userRepository.findByEmail(loginData.getEmail());
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            if (user.getPassword().equals(loginData.getPassword())) {
                return user; // Returns user details including role ('CUSTOMER' or 'ADMIN')
            }
        }
        throw new RuntimeException("Invalid email or password!");
    }
}