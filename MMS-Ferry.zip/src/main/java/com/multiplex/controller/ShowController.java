package com.multiplex.controller;

import com.multiplex.model.*;
import com.multiplex.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class ShowController {

    @Autowired private ShowRepository showRepository;
    @Autowired private ScreenRepository screenRepository;
    @Autowired private SeatRepository seatRepository;

    @GetMapping("/screens")
    public List<Screen> getScreens() { return screenRepository.findAll(); }

    @PostMapping("/screens")
    public Screen addScreen(@RequestBody Screen screen) {
        Screen saved = screenRepository.save(screen);
        for (int i = 1; i <= saved.getCapacity(); i++) {
            Seat seat = new Seat();
            seat.setScreen(saved);
            seat.setSeatNumber("S" + i);
            seat.setSeatType("REGULAR");
            seatRepository.save(seat);
        }
        return saved;
    }

    @GetMapping("/shows/movie/{movieId}")
    public List<Show> getShowsByMovie(@PathVariable Long movieId) {
        return showRepository.findByMovieMovieId(movieId);
    }

    @PostMapping("/shows")
    public Show addShow(@RequestBody Show show) {
        return showRepository.save(show);
    }

    @GetMapping("/seats/screen/{screenId}")
    public List<Seat> getSeatsByScreen(@PathVariable Long screenId) {
        return seatRepository.findByScreenScreenId(screenId);
    }
}