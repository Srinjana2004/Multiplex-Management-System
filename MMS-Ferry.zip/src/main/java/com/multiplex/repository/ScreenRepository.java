package com.multiplex.repository;
import com.multiplex.model.Screen;
import org.springframework.data.jpa.repository.JpaRepository;
public interface ScreenRepository extends JpaRepository<Screen, Long> {}