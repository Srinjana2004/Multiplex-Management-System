package com.multiplex.repository;

import com.multiplex.model.BookingSeat;
import com.multiplex.model.BookingSeatId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface BookingSeatRepository extends JpaRepository<BookingSeat, BookingSeatId> {

    @Query("SELECT bs.seat.seatId FROM BookingSeat bs WHERE bs.booking.show.showId = :showId AND bs.seatStatus = 'RESERVED'")
    List<Long> findReservedSeatIdsByShowId(@Param("showId") Long showId);
}